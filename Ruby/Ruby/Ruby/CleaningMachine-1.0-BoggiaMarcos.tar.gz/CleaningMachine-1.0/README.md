Enter in terminal:
$ ruby CleaningMachine.rb