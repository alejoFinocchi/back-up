require 'test_helper'

class TemporaryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "should not save task with no data" do 
    task = Temporary.new
    assert_not task.save
  end

  test "should save task with correct data" do
  	list = List.create(name: 'test')
    task = Temporary.new(description: 'temporary task', priority: 2, list: list, start_date: '2016-12-01', end_date: '2016-12-10')
    assert task.save
  end

  test "should not save temporary task with start date bigger than end date" do
    list = List.create(name: 'test')
    task = Temporary.new(description: 'temporary task', priority: 2, list: list, start_date: '2016-7-20', end_date: '2016-7-10')
    assert_not task.save
  end

  test "should set expired status to temporary task whose end date is later than today" do
    #Be sure to run this test after 1995
    list = List.create(name: 'test')
    task = Temporary.new(description: 'temporary task', priority: 2, list: list, start_date: '1995-12-01', end_date: '1995-12-10')
    task.save
    task = list.tasks.first
    task.set_expired
    assert task.status == 'Expired'
  end

end
