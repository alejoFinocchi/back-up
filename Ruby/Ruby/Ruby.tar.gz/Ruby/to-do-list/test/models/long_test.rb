require 'test_helper'

class LongTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "should not save task with no data" do 
    task = Long.new
    assert_not task.save
  end

  test "should save task with correct data" do
  	list = List.create(name: 'test')
    task = Long.new(description: 'create webpage with C', priority: 1, list: list)
    assert task.save
  end

  test "should not update long task with percetange out of range" do
    list = List.create(name: 'test')
    task = Long.new(description: 'temporary task', priority: 2, list: list)
    assert_not task.update(percentage: 101)
  end

end
