require 'test_helper'

class SimpleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "should not save task with no data" do 
    task = Simple.new
    assert_not task.save
  end

  test "should save task with correct data" do
  	list = List.create(name: 'test')
    task = Simple.new(description: 'create unit testing', priority: 3, list: list)
    assert task.save
  end

end
