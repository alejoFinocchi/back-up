require 'test_helper'

class ListTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
  test "should not save list with no name" do 
    list = List.new
    assert_not list.save
  end

  test "should save list with unique slug" do 
    list = List.new(name: 'Facultad de Informática')
    list.create_slug
    assert list.save
  end

  test "should not save list with repeated slug" do
    list = List.new(name: 'Cosas que dejé para mañana')
    list.create_slug
    assert_not list.save
  end

end
