require 'test_helper'

class TaskTest < ActiveSupport::TestCase

	test 'should order pending tasks by priority' do
	  	list = List.create(name: 'test')

  	    task = Simple.new(description: 'create unit testing', priority: 1, list: list)
   		task.save

	    task = Long.new(description: 'create webpage with C', priority: 3, list: list)
	    task.save

		task = Temporary.new(description: 'temporary task', priority: 2, list: list, start_date: '2016-12-01', end_date: '2099-12-10')
		task.save

		list = List.where(name: 'test').take

		tasks = list.get_pending_tasks

		assert tasks.first.priority > tasks.second.priority && tasks.second.priority > tasks.third.priority
	end

	test 'should order finished tasks by priority' do
	  	list = List.create(name: 'test')

  	    task = Simple.new(description: 'create unit testing', priority: 1, list: list)
   		task.save

   		task.update(status: 'Done')

	    task = Long.new(description: 'create webpage with C', priority: 3, list: list)
	    task.save

   		task.update(status: 'Done')

		task = Temporary.new(description: 'temporary task', priority: 2, list: list, start_date: '2016-12-01', end_date: '2099-12-10')
		task.save

   		task.update(status: 'Expired')

		list = List.where(name: 'test').take

		tasks = list.get_finished_tasks

		assert tasks.first.priority > tasks.second.priority && tasks.second.priority > tasks.third.priority
	end

end
