# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
lista0 = List.create(name: 'Lista 0')

s = Simple.create(description: 'A simple task description', priority: '3', list: lista0)
Temporary.create(description: 'A temporary task description', priority: '2', list: lista0, start_date: '2016-12-01', end_date: '2016-12-12')
Long.create(description: 'A long task description', priority: '1', list: lista0)

Simple.create(description: 'Another simple task description', priority: '1', list: lista0)
Temporary.create(description: 'Another temporary task description', priority: '3', list: lista0, start_date: '2016-6-03', end_date: '2016-7-10')
l = Long.create(description: 'Another long task description', priority: '2', list: lista0)

s.update(status: 'Done')

l.update(status: 'In progress', percentage: '25')