class CreateTasks < ActiveRecord::Migration[5.0]
  def change
    create_table :tasks do |t|
      t.string :type, null: false
      t.text :description, limit: 255, null: false
      t.string :status, null: false
      t.integer :priority, null: false
      t.datetime :start_date
      t.datetime :end_date
      t.integer :percentage
      t.references :list, foreign_key: true

      t.timestamps
    end
  end
end
