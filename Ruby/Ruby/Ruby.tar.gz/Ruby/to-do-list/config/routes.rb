Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
  get '/', to: 'lists#index', as: 'lists'
  match '/', to: 'lists#create', via: [:post]
  get '/:slug', to: 'lists#show', as: 'list'
  match '/:slug', to: 'lists#update', via: [:put]

  get '/:slug/simple', to: 'tasks/simple#form', as: 'simples'
	get '/:slug/temporary', to: 'tasks/temporary#form', as: 'temporaries'
	get '/:slug/long', to: 'tasks/long#form', as: 'longs'
	
  match '/:slug/simple', to: 'tasks/simple#create', via: [:post]
  match '/:slug/temporary', to: 'tasks/temporary#create', via: [:post]
  match '/:slug/long', to: 'tasks/long#create', via: [:post]

  match '/:slug/simple/:id', to: 'tasks/simple#update', via: [:put]
  match '/:slug/temporary/:id', to: 'tasks/temporary#update', via: [:put]
  match '/:slug/long/:id', to: 'tasks/long#update', via: [:put]

end
