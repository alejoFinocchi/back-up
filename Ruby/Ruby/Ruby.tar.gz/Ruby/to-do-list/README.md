# README

# To-Do-List

* Ruby version: ruby 2.3.2p217 ---- Rails 5.0.0.1

## Installation

    $ bundle install
    $ rails db:setup
    $ rails db:seed

## Usage

To run server:

    $ rails s 

To run tests:

    $ rails t