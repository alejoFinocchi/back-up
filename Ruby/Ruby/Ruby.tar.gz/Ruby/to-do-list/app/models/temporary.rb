class Temporary < Task
	validates_datetime :start_date
	validates_datetime :end_date, :after => :start_date, after_message: "must be later than start date"

  	def init
    	super
    	self.type  = 'Temporary'
    end

	def set_expired
		if self.end_date < Date.today
			self.update(status: 'Expired')
			true
		else
			false
		end
	end

end