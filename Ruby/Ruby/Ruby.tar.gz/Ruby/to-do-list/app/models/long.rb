class Long < Task
	validates :percentage, numericality: { only_integer: true, greater_than_or_equal_to: 0, less_than_or_equal_to: 100 }
  	
  	def init
		super
		self.type  = 'Long'
		self.percentage ||= 0
    end

end
