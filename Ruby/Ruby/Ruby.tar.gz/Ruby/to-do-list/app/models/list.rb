class List < ApplicationRecord
	validates :name, uniqueness: true, presence: true, format: { with: /[a-zA-Z0-9]/, message: "only allows letters and numbers" }
	before_validation :create_slug
	validates :slug, uniqueness: true
	has_many :tasks
	
	def to_s
		name		
	end

	def self::with_these_id(array)
		List.all.select do |list|
			array.include? list.id
		end
	end

 	def create_slug
		self.slug = I18n.transliterate(self.name).gsub(/\s/, '-').downcase if !name.nil? && slug.nil?
	end

	def get_pending_tasks
		pending_tasks = self.tasks.where(status: ['Pending', 'In progress']).order("priority DESC")
		pending_tasks.reject { |task| task.set_expired }
	end

	def get_finished_tasks
		self.tasks.where(status: ['Expired', 'Done']).order("priority DESC")
	end

end