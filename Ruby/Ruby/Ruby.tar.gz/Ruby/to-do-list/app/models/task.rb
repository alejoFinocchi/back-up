class Task < ApplicationRecord
	after_initialize :init
	validates :description, presence: true
	validates :priority, presence: true, numericality: { only_integer: true, greater_than_or_equal_to: 1, less_than_or_equal_to: 3 }
	validates :list_id, presence: true, numericality: { only_integer: true }
  belongs_to :list
  

  	def init
    	self.status  ||= 'Pending' # Will set the default value only if it's nil
    end

    def set_expired
      false
    end
end
