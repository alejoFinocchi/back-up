class Simple < Task

  	def init
		super
		self.type  = 'Simple'
    end

end
