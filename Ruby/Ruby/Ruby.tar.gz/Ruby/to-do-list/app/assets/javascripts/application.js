// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, vendor/assets/javascripts,
// or any plugin's vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery
//= require jquery-ui
//= require bootstrap
//= require jquery_ujs
//= require turbolinks
//= require bootstrap-sprockets
//= require editable/jqueryui-editable
//= require editable/rails
//= require tether

function create_task(type){
	var form = $('.add_task_form');

	$.ajax({
		url: get_list_link() + '/' + type,
		type: 'post',
		data: form.serialize(),
		success: function(data){
			show_task_form(data);

		},
		error: function(data){
			show_task_form(data);
		}
	});
};

function show_task_form(data){
	$('#add_task_form').html(data);
	$( "#temporary_start_date" ).datepicker({ dateFormat: 'yy-mm-dd' }); // Anda cuando tiene ganas
	$( "#temporary_end_date" ).datepicker({ dateFormat: 'yy-mm-dd' });
};

function get_list_link(){
	var a_element = document.createElement("a");
	a_element.href = window.location.href;
	link = a_element.pathname;
	return link;
};

$(document).on('turbolinks:load', function() {

// X-Editable
$.fn.editable.defaults.mode = 'inline';
$('.editable').editable({
	error: function(errors){
		return errors.responseJSON.toString().replace(/,/g, ".\n")
	}
});
//

$(document).ready(function(){

	var list = get_list_link();

	$('#add_simple_button').click(function() {
		$.ajax({
			url: list + '/simple',
			success: function(data){
				show_task_form(data);
			}
		});
	});

	$('#add_temporary_button').click(function() {
		$.ajax({
			url: list + '/temporary',
			success: function(data){
				show_task_form(data);
			}
		});
	});

	$('#add_long_button').click(function() {
		$.ajax({
			url: list + '/long',
			success: function(data){
				show_task_form(data);
			}
		});
	});

	$('#show_finished').click(function() {
		$('#pending_table').hide();
		$('#finished_table').show();
	});

	$('#show_pending').click(function() {
		$('#finished_table').hide();
		$('#pending_table').show();
	});

});




});