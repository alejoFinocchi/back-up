class ListsController < ApplicationController
	before_action :get_list, only: [:show, :update]
	before_action :get_lists, only: [:create]

	def index
	    session[:lists] = [] if session[:lists].nil?
	    @lists = get_lists
	    @list = List.new
	end

	def show

	end

	def create
	    @list = List.new(list_params)
	    respond_to do |format|
	      if @list.save
	        session[:lists] << @list.id
	        format.html { redirect_to "/#{@list.slug}", notice: 'List was successfully created.' }
	        format.json { render :show, status: :created, location: @list }
	      else
	        format.html { render :index }
	        format.json { render json: @list.errors.full_messages, status: :unprocessable_entity }
	      end
	    end
	end

	def update
	    respond_to do |format|
	      if @list.update(list_params)
	        format.html { redirect_to "/#{@list.slug}", notice: 'Name was successfully updated.' }
	        format.json { render :show, status: :ok, location: @list }
	      else
	        format.json { render json: @list.errors.full_messages, status: :unprocessable_entity }
	      end
    	end
	end

  private
    # Use callbacks to share common setup or constraints between actions.
    def get_list
    	@list = List.find_by(slug: params[:slug])
   	end

   	def get_lists
   		@lists = List.with_these_id(session[:lists])
   	end
    # Never trust parameters from the scary internet, only allow the white list through.
    def list_params
      params.require(:list).permit(:name, :slug)
    end
end