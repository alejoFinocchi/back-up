class Tasks::AbstractController < ApplicationController

	before_action :get_task, only: [:update]
	before_action :get_list, only: [:update, :create]
	add_views_path :tasks

	def save
		@task.list = @list
	    respond_to do |format|
	      if @task.save
	      	@list.touch #Update list updated_at
	        format.html { redirect_to "/#{@list.slug}", notice: 'Task was successfully added.' }
	        format.json { render json: @task }
	      else
	        format.html { render partial: 'form' }
	        format.json { render json: @task.errors, status: :unprocessable_entity }
	      end
	    end
	end

	def update
	    respond_to do |format|
	      if @task.update(task_params)
	      	@list.touch #Update list updated_at
	        format.html { redirect_to "/#{@list.slug}", notice: 'Atribute was successfully updated.' }
	        format.json { render json: @task }
	      else
	        format.html { redirect_to "/#{@list.slug}", notice: "Atribute couldn't be updated."  }
	        format.json { render json: @task.errors.full_messages, status: :unprocessable_entity }
	      end
    	end
	end

  private
    
    def get_task
    	@task = Task.find(params[:id])
   	end

    def get_list
    	@list = List.find_by(slug: params[:slug])
   	end

end
