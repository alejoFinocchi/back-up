class Tasks::SimpleController < Tasks::AbstractController

	def form
		@task = Simple.new
		render partial: 'form'
	end

	def create
	    @task = Simple.new(task_params)
	    save
	end

  private
    
    def task_params
      params.require(:simple).permit(:slug, :description, :priority, :status)
   	end
end
