class Tasks::TemporaryController < Tasks::AbstractController

	def form
		@task = Temporary.new
		render partial: 'form'
	end

	def create
		@task = Temporary.new(task_params)
		save
	end

  private

    def task_params
      params.require(:temporary).permit(:slug, :description, :priority, :status, :start_date, :end_date)
   	end

end
