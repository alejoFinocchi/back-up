class Tasks::LongController < Tasks::AbstractController

	def form
		@task = Long.new
		render partial: 'form'
	end

	def create
	    @task = Long.new(task_params)
	    save
	end

  private

    def task_params
      params.require(:long).permit(:slug, :description, :priority, :status, :percentage)
   	end
end

