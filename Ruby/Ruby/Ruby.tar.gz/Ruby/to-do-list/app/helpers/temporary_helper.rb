module TemporaryHelper
end
