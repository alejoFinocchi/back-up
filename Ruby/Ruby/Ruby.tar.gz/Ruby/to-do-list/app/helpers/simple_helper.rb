module SimpleHelper
end
