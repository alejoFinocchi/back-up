require 'colorputs'
puts "Hola!", :rainbow_bl
