# README

# Turnos-Online

* Web application made for fitness club to help them and their clients setup and coordinate training sessions by booking them.

# Versions

* Ruby 2.4.1
* Rails 5.3.1

## Installation

    $ bundle install
    $ rails db:migrate
    $ rails db:setup
    $ rails db:seed

## Usage

To run server:

    $ rails s 

## Gems used

* Validates timeliness: https://github.com/adzap/validates_timeliness
* Devise: https://github.com/plataformatec/devise
