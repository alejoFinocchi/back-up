class CreateActivities < ActiveRecord::Migration[5.1]
  def change
    create_table :activities do |t|
      t.string :name, null: false
      t.decimal :price, null: false
      t.belongs_to :branch, null: false

      t.timestamps
    end
    add_index(:activities, [:name, :branch_id], unique: true)
  end
end
