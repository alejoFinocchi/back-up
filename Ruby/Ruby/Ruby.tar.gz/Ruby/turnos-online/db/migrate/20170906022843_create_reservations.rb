class CreateReservations < ActiveRecord::Migration[5.1]
  def change
    create_table :reservations do |t|
      t.belongs_to :client, index: true
      t.belongs_to :turn, index: true
    end
  end
end
