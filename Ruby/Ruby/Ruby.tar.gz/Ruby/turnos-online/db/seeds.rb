# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

owners = Owner.create([{ email: 'martin@hotmail.com', password: 'abcde132', entity_name: 'Vibrate' },
										  { email: 'gonzalo@hotmail.com', password: 'abcde132', entity_name: 'Tuluca' }])

clients = Client.create([{ email: 'marcos_boggia@hotmail.com', password: 'abcde132', first_name: 'Marcos', last_name: 'Boggia', dni: '65321312', date_of_birth: '1995-09-18', phone: '2213213434' },
											 { email: 'client@hotmail.com', password: 'abcde132', first_name: 'Name', last_name: 'LasName', dni: '65365312', date_of_birth: '2000-09-18', phone: '2216543434' }])

branches = Branch.create([{ address: "47 321", city: "La Plata", province: "Buenos Aires", country: "Argentina", owner_id: owners.first.id}, 
													{ address: "56 1511", city: "La Plata", province: "Buenos Aires", country: "Argentina", owner_id: owners.first.id},
													{ address: "44 123", city: "La Plata", province: "Buenos Aires", country: "Argentina", owner_id: owners.last.id}])

activities = Activity.create([{ name: "Crossfit", price: "100", branch_id: branches.first.id}, 
															{ name: "Functional", price: "80", branch_id: branches.first.id},
															{ name: "Crossfit", price: "120", branch_id: branches.last.id}])

turns = Turn.create([{date: "2017-09-29 15:00:00", capacity: "10", activity_id: activities.first.id}, 
										 {date: "2017-09-29 20:00:00", capacity: "10", activity_id: activities.first.id},
										 {date: "2017-10-02 09:30:00", capacity: "12", activity_id: activities.first.id},
										 {date: "2017-10-02 15:00:00", capacity: "12", activity_id: activities.first.id},
										 {date: "2017-10-02 19:00:00", capacity: "12", activity_id: activities.first.id},
										 {date: "2017-10-02 20:00:00", capacity: "12", activity_id: activities.first.id}])

Ticket.create([{ amount: "8", client_id: clients.first.id, activity_id: activities.first.id }])