module ApplicationHelper

	# Returns the class by the name given, if an unknown class is given with malicious intent, it raises exception.
	# Used in registration controller to get the class from the type received in registration form, to automatically specify which attributes should be permitted to that type.

	def class_for(aName)
		Rails.application.eager_load! # Needed to load and know Users subclasses
		types = Hash[
			User.subclasses.map do |type| 
				[type.name, type] 
			end
		]
		if types[aName] then types[aName] else raise UnknownClass end
	end

end

