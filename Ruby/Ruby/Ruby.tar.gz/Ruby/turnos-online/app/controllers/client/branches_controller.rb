class Client::BranchesController < BranchesController
  before_action do 
    check_role_for("Client")
    set_entity_name_from_parameter
  end
  before_action :set_owner_from_entity_name, only: [:index]

  # GET client/:entity_name/branches
  # GET client/:entity_name/branches.json
  def index
    @branches = @owner.branches
  end

  # GET client/:entity_name/branches/:id
  # GET client/:entity_name/branches/:id.json
  def show

  end

end
