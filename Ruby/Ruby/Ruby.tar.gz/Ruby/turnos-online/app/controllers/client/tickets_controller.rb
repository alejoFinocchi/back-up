class Client::TicketsController < TicketsController

  # GET /client/tickets
  # GET /client/tickets.json
  def index
    @tickets = current_user.tickets
  end
  
end