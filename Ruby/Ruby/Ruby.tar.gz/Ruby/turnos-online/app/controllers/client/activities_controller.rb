class Client::ActivitiesController < ActivitiesController
  before_action do 
    check_role_for("Client")
    set_entity_name_from_parameter
  end
  before_action :set_owner_from_entity_name, only: [:index]

  # GET client/:entity_name/branches/:branch_id/activities
  # GET client/:entity_name/branches/:branch_id/activities.json
  def index

  end

	# GET client/:entity_name/activities/:id
  # GET client/:entity_name/activities/:id.json
  def show
    ticket = Ticket.find_by_client_id_and_activity_id(current_user, @activity)
    @ticket_amount = (ticket.amount if ticket) || 0
  end
  
end