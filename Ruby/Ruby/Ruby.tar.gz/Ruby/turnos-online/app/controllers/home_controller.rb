class HomeController < ApplicationController
	

	# GET /
	def index
		# Home for logged in accounts.
  	if user_signed_in? then
  		redirect_to "/" + current_user.type.downcase
  	end

  	# Home for not logged in

  end

end