class TurnsController < ApplicationController
  before_action :set_turn, :set_activity, only: [:show, :edit, :update, :destroy]
  before_action :set_activity_from_path, only: [:new, :create]
  
  def show
    
  end

  protected
    # Use callbacks to share common setup or constraints between actions.
    def set_turn
      @turn = Turn.find(params[:id])
    end

    def set_activity_from_path
      @activity = Activity.find(params["activity_id"])
    end

    def set_activity
      @activity = Activity.find(@turn.activity_id)
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def turn_params
      params.require(:turn).permit(:date, :capacity)
    end

end
