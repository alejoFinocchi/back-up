class Owner::TurnsController < TurnsController
  before_action do check_role_for("Owner") end
  before_action :check_owner, only: [:show, :edit, :update, :destroy] 
  before_action :set_clients_from_turn, only: [:show]

  # GET /owner/activity/1/turns/new
  def new
    @turn = Turn.new
  end

  # GET /owner/turns/1/edit
  def edit
  end

  # POST /owner/activity/1/turns
  # POST /owner/activity/1/turns.json
  def create
    @turn = Turn.new(turn_params)
    @turn.activity_id = @activity.id if current_user.branches.includes(@activity.branch_id)
    respond_to do |format|
      if @turn.save
        format.html { redirect_to owner_turn_path(@turn), notice: 'Turn was successfully created.' }
        format.json { render :show, status: :created, location: @turn }
      else
        format.html { render :new }
        format.json { render json: @turn.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /owner/turns/1
  # PATCH/PUT /owner/turns/1.json
  def update
    respond_to do |format|
      if @turn.update(turn_params)
        format.html { redirect_to owner_turn_path(@turn), notice: 'Turn was successfully updated.' }
        format.json { render :show, status: :ok, location: @turn }
      else
        format.html { render :edit }
        format.json { render json: @turn.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /owner/turns/1
  # DELETE /owner/turns/1.json
  def destroy
    @turn.destroy
    respond_to do |format|
      format.html { redirect_to owner_activity_path(@activity), notice: 'Turn was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private

    # Checks if current user is the owner of the current turn for showing, editing, updating and deleting.
    def check_owner
      redirect_to '/', :notice => "You are not the owner of that turn" unless @turn.branch.owner_id == current_user.id
    end

    def set_clients_from_turn
      @clients = Array(Client.find_by_id(@turn.client_ids))
    end

end
