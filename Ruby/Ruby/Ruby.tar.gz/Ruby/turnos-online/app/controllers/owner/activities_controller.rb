class Owner::ActivitiesController < ActivitiesController
  before_action do check_role_for("Owner") end
  before_action :check_owner, only: [:show, :edit, :update, :destroy]

  # GET /owner/branches/1/activities/new
  def new
    @activity = Activity.new
  end

  # GET /owner/activities/1/edit
  def edit
  end

  # POST /owner/branches/1/activities
  # POST /owner/branches/1//activities.json
  def create
    @activity = Activity.new(activity_params)
    @activity.branch_id = @branch.id if current_user.branches.includes(@branch.id)
    respond_to do |format|
      if @activity.save
        format.html { redirect_to owner_activity_path(@activity), notice: 'Activity was successfully created.' }
        format.json { render :show, status: :created, location: @activity }
      else
        format.html { render :new }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /owner/activities/1
  # PATCH/PUT /owner/activities/1.json
  def update
    respond_to do |format|
      if @activity.update(activity_params)
        format.html { redirect_to owner_activity_path(@activity), notice: 'Activity was successfully updated.' }
        format.json { render :show, status: :ok, location: @activity }
      else
        format.html { render :edit }
        format.json { render json: @activity.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /owner/activities/1
  # DELETE /owner/activities/1.json
  def destroy
    @activity.destroy
    respond_to do |format|
      format.html { redirect_to owner_branch(@branch), notice: 'Activity was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private

    # Checks if current user is the owner of the current activity for showing, editing, updating and deleting.
    def check_owner
      redirect_to '/', :notice => "You are not the owner of that activity" unless @activity.branch.owner_id == current_user.id
    end

end
