class Owner::BranchesController < BranchesController
  before_action do check_role_for("Owner") end
  before_action :check_owner, only: [:show, :edit, :update, :destroy]

  # GET /owner/branches/new
  def new
    @branch = Branch.new
  end

  # GET /owner/branches/1/edit
  def edit
  end

  # POST /owner/branches
  # POST /owner/branches.json
  def create
    @branch = Branch.new(branch_params)
    @branch.owner_id = current_user.id
    respond_to do |format|
      if @branch.save
        format.html { redirect_to owner_branch_path(@branch), notice: 'Branch was successfully created.' }
        format.json { render :show, status: :created, location: @branch }
      else
        format.html { render :new }
        format.json { render json: @branch.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /owner/branches/1
  # PATCH/PUT /owner/branches/1.json
  def update
    respond_to do |format|
      if @branch.update(branch_params)
        format.html { redirect_to owner_branch_path(@branch), notice: 'Branch was successfully updated.' }
        format.json { render :show, status: :ok, location: @branch }
      else
        format.html { render :edit }
        format.json { render json: @branch.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /owner/branches/1
  # DELETE /owner/branches/1.json
  def destroy
    @branch.destroy
    respond_to do |format|
      format.html { redirect_to owner_path, notice: 'Branch was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private

    # Checks if current user is the owner of the current branch for showing, editing, updating and deleting.
  def check_owner
    redirect_to '/', :notice => "You are not the owner of that branch" unless @branch.owner_id == current_user.id
  end

end
