class Owner::HomeController < HomeController
  before_action do check_role_for("Owner") end

	def index

	end

end
