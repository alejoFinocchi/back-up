class Owner::TicketsController < TicketsController
  before_action do check_role_for("Owner") end
	before_action :set_activity_id
	before_action :set_client, :set_activity, :check_activity_owner, only: [:create]

  # GET /owner/activities/:activity_id/tickets/new
  def new
    @ticket = Ticket.new
		render partial: 'form'
  end

  # POST /owner/activities/:activity_id/tickets
  # POST /owner/activities/:activity_id/tickets.json
  def create
  	begin
    if @ticket = Ticket.find_by_client_id_and_activity_id(@client.id, @activity.id)
    	@add_amount = ticket_params[:amount].to_i
    	@new_amount = @ticket.amount += @add_amount
    	@ticket.update!(amount: @new_amount)
			renderSuccessfullResponse
   	else
      @add_amount = @new_amount = ticket_params[:amount]
   		@ticket = Ticket.new(amount: @new_amount, client_id: @client.id, activity_id: @activity.id )
   		@ticket.save!
			renderSuccessfullResponse
	  end

	  rescue
			renderErrorResponse
		end
  end

  private

  # Used to render the form with success message and new amount of ticket.
  def renderSuccessfullResponse
    respond_to do |format|
    	flash[:notice] = @add_amount.to_s + " ticket/s added successfully to " + @client.email + " for " + @activity.name + ". New amount: " + @new_amount.to_s
      format.html { render partial: 'form' }
      format.json { render :show, status: :created, location: @ticket }
    end
  end

  # Used to render the form with error messages
  def renderErrorResponse
	  respond_to do |format|
			format.html { render partial: 'form' }
			format.json { render json: @ticket.errors, status: :unprocessable_entity }
		end
  end

  # Check if the email given is a valid email
  def set_client
  	begin
  	@client = Client.find_by_email!(ticket_params[:email])
		rescue ActiveRecord::RecordNotFound
			@ticket = Ticket.new
			@ticket.errors.add(:client_id, :email, message: "not found")
			renderErrorResponse
  	end
  end

  # Check if activity given exists
  def set_activity
  	begin
  	@activity = Activity.find_by_id!(@activity_id)
		rescue ActiveRecord::RecordNotFound
			@ticket = Ticket.new
			@ticket.errors.add(:activity_id, :activity, message: "not found")
			renderErrorResponse
  	end  	
  end

	# Check if activity given is owned by current user
  def check_activity_owner
  	begin
  	raise SecurityError unless current_user.activities.include?(@activity)
		rescue SecurityError
			@ticket = Ticket.new
			@ticket.errors.add(:activity_id, :activity, message: " is invalid. You are no the owner")
			renderErrorResponse
  	end  	
  end

  def set_activity_id
  	@activity_id = params[:activity_id]
  end

  # Never trust parameters from the scary internet, only allow the white list through.
  def ticket_params
    params.require(:ticket).permit(:amount, :email)
  end
end
