class TicketsController < ApplicationController


end
