class Reservation < ApplicationRecord
  belongs_to :client
  belongs_to :turn
	validates_uniqueness_of :client, scope: [:turn], message: "is already on that turn"
	validate :turns_cannot_be_greater_than_capacity

	def turns_cannot_be_greater_than_capacity
    if turn.reservations.size >= turn.capacity
      errors.add(:reservation, "is full")
    end
	end

end