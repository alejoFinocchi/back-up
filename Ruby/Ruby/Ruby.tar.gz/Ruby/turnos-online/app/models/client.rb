class Client < User
	validates :first_name, presence: true, format: { with: /[a-zA-Z]+/, message: "only allows letters" }
	validates :last_name, presence: true, format: { with: /[a-zA-Z]+/, message: "only allows letters" }
	validates_date :date_of_birth, before: lambda { Date.current }, :before_message => "is too recent"
	validates :dni, presence: true, uniqueness: true, numericality: { only_integer: true, greater_than_or_equal_to: 10000, less_than_or_equal_to: 999999999 }
	validates :phone, presence: true, uniqueness: true, format: { with: /\b\d{3}[-.]?\d{3}[-.]?\d{4}\b/, message: "has incorrect format" }
  has_many :reservations, dependent: :destroy
  has_many :turns, through: :reservations
  has_many :tickets, dependent: :destroy

	def init
		self.type  = 'Client' # Set the type for STI when creating a client account
	end

	# Returns the attributes that differs from the other types.
	def self.attributes_names_bounded
		[:first_name, :last_name, :date_of_birth, :dni, :phone]
	end

	# Got from https://stackoverflow.com/questions/819263/get-persons-age-in-ruby, to get age from date of birth, taking into account the leap year.
	def age
	  now = Time.now.utc.to_date
	  now.year - date_of_birth.year - ((now.month > date_of_birth.month || (now.month == date_of_birth.month && now.day >= date_of_birth.day)) ? 0 : 1)
	end

end