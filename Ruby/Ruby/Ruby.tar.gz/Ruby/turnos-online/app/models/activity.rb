class Activity < ApplicationRecord
	validates :name, presence: true, format: { with: /[a-zA-Z]/, message: "only allows letters" }
	validates_uniqueness_of :name, scope: [:branch_id]
	validates :price, presence: true, numericality: { only_integer: true }
	validates :branch_id, presence: true
	belongs_to :branch
	has_many :turns, dependent: :destroy

end
