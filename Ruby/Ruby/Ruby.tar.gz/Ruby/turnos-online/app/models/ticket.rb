class Ticket < ApplicationRecord
	belongs_to :activity
	belongs_to :client
	validates_uniqueness_of :client_id, scope: [:activity_id]
	validates :activity_id, presence: true
	validates :client_id, presence: true
	validates :amount, presence: true, numericality: { only_integer: true }

end
