class Branch < ApplicationRecord
	validates :address, presence: true, format: { with: /[a-zA-Z0-9]/, message: "only allows letters and numbers" }
	validates :city, presence: true, format: { with: /[a-zA-Z]/, message: "only allows letters" }
	validates :province, presence: true, format: { with: /[a-zA-Z]/, message: "only allows letters" }
	validates :country, presence: true, format: { with: /[a-zA-z]/, message: "only allows letters" }
	validates :owner_id, presence: true
	validates_uniqueness_of :address, scope: [:city, :province, :country, :owner_id]
	has_many :activities, dependent: :destroy
	belongs_to :owner
	
end
