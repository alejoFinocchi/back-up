class Owner < User
	validates :entity_name, presence: true, uniqueness: true, format: { with: /[a-zA-Z0-9]/, message: "only allows letters and numbers" }
	before_validation :create_slug, on: :create
	before_validation :update_slug, on: :update
	validates :slug, uniqueness: true
	has_many :branches, dependent: :destroy
  has_many :activities, through: :branches

	def init
		self.type  = 'Owner' # Set the type for STI when creating an owner account
	end

 	def create_slug
		generate_slug if !entity_name.nil? && slug.nil?
	end

	def update_slug
		generate_slug
	end

	# Returns the attributes that differs from the other types.
	def self.attributes_names_bounded
		[:entity_name]
	end

	private
	def generate_slug
		self.slug = I18n.transliterate(self.entity_name).gsub(/\s/, '-').downcase
	end

end