class Turn < ApplicationRecord
	validates_datetime :date, after: lambda { Time.current }, :after_message => "must be later than now"
	validates_uniqueness_of :date, scope: [:activity_id]
	validates :capacity, presence: true, numericality: { only_integer: true }
	validates :activity_id, presence: true
  has_many :reservations, dependent: :destroy
  has_many :clients, through: :reservations
  belongs_to :activity
  delegate :branch, to: :activity

end