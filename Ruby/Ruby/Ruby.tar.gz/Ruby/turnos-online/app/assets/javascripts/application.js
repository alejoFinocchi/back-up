// This is a manifest file that'll be compiled into application.js, which will include all the files
// listed below.
//
// Any JavaScript/Coffee file within this directory, lib/assets/javascripts, or any plugin's
// vendor/assets/javascripts directory can be referenced here using a relative path.
//
// It's not advisable to add code directly here, but if you do, it'll appear at the bottom of the
// compiled file. JavaScript code in this file should be added after the last require_* statement.
//
// Read Sprockets README (https://github.com/rails/sprockets#sprockets-directives) for details
// about supported directives.
//
//= require jquery
//= require jquery-ui
//= require jquery_ujs
//= require popper
//= require bootstrap-sprockets
//= require bootstrap
//= require rails-ujs
//= require turbolinks
//= require bootstrap-select
//= require bootstrap/alert
//= require bootstrap/dropdown
//= require datetimepicker
//= require_tree .

// FUNCTIONS

//// USER REGISTRATION ////

function setDefaultFormByType(type){
	$("#user_type").val(type); //Set default value selected in type select for client account creation
	setClientAttributes();
}

function setClientAttributes(){
  $("#entity_name").hide();
	$("#first_name").show();
	$("#last_name").show();
	$("#dni").show();
	$("#date_of_birth").show();
	$("#phone").show();
}

function setOwnerAttributes(){
	$("#entity_name").show();
	$("#first_name").hide();
	$("#last_name").hide();
	$("#dni").hide();
	$("#date_of_birth").hide();
	$("#phone").hide();
}

function setResoruceRegistrationRoute(){
	$("#new_user").attr("action", "/" + $("#user_type").val().toLowerCase());
}

//// RESERVES ////

function reservate(turn_id){
	$.ajax({
		url: '/client/reservate',
		type: 'post',
		data: {'turn_id': turn_id },
		success: function(data){
			renderSuccessfullReservation(data, turn_id)
		},
		error: function(data){
			$("#notice").text(data.responseJSON.notice);
		}
	});
}

function renderSuccessfullReservation(data, turn_id){
	$("#notice").text(data.notice);
	$("#" + turn_id + "_current_capacity").text($("#" + turn_id + "_current_capacity").text().replace(/\d*\//, data.new_capacity + "/"));
	$("#ticket-amount").text( parseInt( $("#ticket-amount").text() ) - 1 )
	$("#" + turn_id).parent().append("Reserved!");
	$("#" + turn_id).parent().get(0).classList.add("btn");
	$("#" + turn_id).parent().get(0).classList.add("medium-font");
	$("#" + turn_id).hide();
}

 //// TICKETS ////

function ticket_form(activity_id){
	$.ajax({
		url: '/owner/activities/' + activity_id + '/tickets/new',
		success: function(data){
			$('#ticket_form').html(data);
		}
	});
};

function add_tickets(activity_id){
	var form = $('#add_ticket_form');

	$.ajax({
		url: '/owner/activities/' + activity_id + '/tickets',
		type: 'post',
		data: form.serialize(),
		success: function(data){
			$('#ticket_form').html(data);
		},
		error: function(data){
			$('#ticket_form').html(data);
		}
	});
}

function get_activity_id_for_ticket(){
	return $('#ticket_form').data('activity_id');
}

///////////////////////////////////////////////////////////////////////////

$(document).on('turbolinks:load', function() {

$(document).ready(function(){

	// Adds date selector to any #datepicker. Currently being used in add/edit user.
	$('#datepicker').datetimepicker({
		timepicker: false,
		format: "Y-m-d"
	});

	// REGISTRATION
	if ($("body").attr("class") == "registrations new"){ // Only excecute this code when it's registration page. Not a fancy way to do it
		setDefaultFormByType('Client');
		$("#user_type").on("change", function() { //Set the correct form for each type of user
		  if($(this).val() == "Client") {
		  	setClientAttributes();
		  }else{
		  	setOwnerAttributes();
		  }
		});
	}
	///////////////////////////////

	// RESERVES

	$(".reserve-button").on("click", function() {
		reservate(this.id);
	});

	///////////////////////////////


	//TICKETS

	$('#add_ticket_form_button').on("click", function() {
		$(this).hide();
		ticket_form(get_activity_id_for_ticket());
	});

	$('#ticket_form').on("click", "#close_ticket_button", function() {
		$('#ticket_form').empty();
		$('#add_ticket_form_button').show();
	});

	$('#ticket_form').on("click", '#add_ticket_submit', function() {
		add_tickets(get_activity_id_for_ticket());
	});

	///////////////////////////////

	// TURNS

	$('#datetimepicker').datetimepicker({
	});

	///////////////////////////////
});
});