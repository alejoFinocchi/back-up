require "application_system_test_case"

class BranchesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit branches_url
  #
  #   assert_selector "h1", text: "Branch"
  # end
end
