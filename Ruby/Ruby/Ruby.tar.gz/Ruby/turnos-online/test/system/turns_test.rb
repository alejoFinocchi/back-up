require "application_system_test_case"

class TurnsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit turns_url
  #
  #   assert_selector "h1", text: "Turn"
  # end
end
