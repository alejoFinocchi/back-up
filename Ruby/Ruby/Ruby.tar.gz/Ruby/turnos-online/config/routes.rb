Rails.application.routes.draw do

  root to: 'home#index'
 
  namespace :owner do
    get '/', to: 'home#index', as: ''
  	resources :branches, except: [:index] do
  		resources :activities, shallow: true do
        resources :tickets, only: [:create, :new]
  		  resources :turns, shallow: true
  		end
  	end
  end

  namespace :client do
    get '/', to: 'home#index', as: ''
    post '/reservate', to: 'reservations#reservate', as: 'reserve'
    resources :tickets, only: [:index]
    scope ':slug' do
      resources :branches, only: [:index, :show] do
        resources :activities, only: [:index, :show], shallow: true
      end
    end
  end

  devise_for :users, controllers: {
        sessions: 'users/sessions',
        registrations: 'users/registrations'
      }

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end