module Countable
	def count_invocations_of(sym)

	end

	def invoked?(sym)

	end

	def invoked(sym)

	end
end