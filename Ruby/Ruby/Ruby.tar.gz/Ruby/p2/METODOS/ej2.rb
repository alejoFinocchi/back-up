def ordenar_arreglo(a, b, c, d, e, f, g)
	[a, b, c, d, e, f, g].sort
end

puts ordenar_arreglo(1, 4, 6, 2, 3, 0, 10)