def ordenar_arreglo(*entrada)
	entrada.sort
end

puts ordenar_arreglo(10, 9, 1, 2, 3, 5, 7, 8)