def ordenar_arreglo(arr)
	arr.sort
end

puts ordenar_arreglo([1, 4, 6, 2, 3, 0, 10])