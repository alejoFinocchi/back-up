[:upcase, :downcase, :capitalize, :swapcase].map do |meth|
	"TTPS Ruby".send(meth)
end
