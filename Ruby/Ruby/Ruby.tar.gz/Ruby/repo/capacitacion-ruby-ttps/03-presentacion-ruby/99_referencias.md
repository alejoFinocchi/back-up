!SLIDE center transition=uncover
# Referencias

!SLIDE smbullets transition=uncover
# Referencias
* [PickAxe](http://www.ruby-doc.org/docs/ProgrammingRuby/)
* [why's (poignant) Guide to Ruby](http://www.rubyinside.com/media/poignant-guide.pdf)
* Muy inspirado en la gran presentación de Jano González presentada en la
  RubyConf 2012 Argentina
  * [¿Donde están mis interfaces?](https://speakerdeck.com/janogonzalez/donde-estan-mis-interfaces)
