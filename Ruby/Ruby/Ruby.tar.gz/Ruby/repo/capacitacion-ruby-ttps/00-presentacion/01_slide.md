!SLIDE center
![Ruby logo](ruby.png)
# Tecnologías de Producción de Software
## Opción Ruby

!SLIDE smbullets transition=uncover
# La cátedra 
* **Profesor:** Lic. Christian A. Rodríguez 
  [![car@info.unlp.edu.ar](mail.png)](mailto:car@info.unlp.edu.ar "car@info.unlp.edu.ar")
  [![twitter](twitter.png)](https://twitter.com/car_unlp "twitter")
  [![github](github.png)](https://github.com/chrodriguez "github")

* **JTP:** APU Nahuel Cuesta Luengo
  [![ncuesta@cespi.unlp.edu.ar](mail.png)](mailto:ncuesta@cespi.unlp.edu.ar "ncuesta@cespi.unlp.edu.ar")
  [![twitter](twitter.png)](https://twitter.com/ncuestal "twitter") 
  [![github](github.png)](https://github.com/ncuesta "github")

* **Ayudantes:** 
  * Lic. Patricio Mac Adden 
  [![patriciomacadden@gmail.com](mail.png)](mailto:patriciomacadden@gmail.com "patriciomacadden@gmail.com") 
  [![twitter](twitter.png)](https://twitter.com/maxawen "twitter") 
  [![github](github.png)](https://github.com/patriciomacadden "github")
  * Lautaro De León 
  [![ldeleon@cespi.unlp.edu.ar](mail.png)](mailto:ldeleon@cespi.unlp.edu.ar "ldeleon@cespi.unlp.edu.ar")
* **Colaboradores:**
  * Fernando Martinez
  [![fernando.martinez@live.com.ar](mail.png)](mailto:fernando.martinez@live.com.ar "fernando.martinez@live.com.ar")
  [![twitter](twitter.png)](https://twitter.com/F_3r "twitter")
  [![github](github.png)](https://github.com/f-3r "github")


!SLIDE bullets transition=uncover
# Horarios de cursada
* **Lunes de 19 a 21 Aula 1-1**
* **Jueves de 19 a 21 Aula 1-1**

!SLIDE smbullets transition=uncover
# Programa
* Metodologías ágiles
* Sistemas de control de versiones: GIT
* El lenguaje Ruby
  * Introducción
  * VMs: MRI, Rubinius, jRuby
  * Preparación del entorno
  * Objetos, arreglos, hashes, símbolos, tipos estándar
  * Estructuras de control
  * Bloques e iteradores
  * E/S estandar
  * Clases de objetos, métodos y variables
  * Módulos y mixins

!SLIDE smbullets transition=uncover
# Programa
* TDD
* Gemas: rubygems
* Rake
* Bundler
* HTTP
* La web
  * Rack
  * Sinatra
  * ORMs
  * Rails

!SLIDE smbullets transition=uncover
# Modalidad de cursada
* Clases teórico prácticas: generalmente avanzaremos con las teorías los días
  Jueves, dejando los Lunes para consultas o talleres prácticos
* Aprobación de la cursada: *será necesario aprobar*
  * Entregas de un ejercicio por práctico que se desarrollará en clase. Habrá
    una evaluación por práctico (salvo el primero)
  * Trabajo práctico final integrador
* Aprobación de la materia mediante extensión del trabajo práctico y coloquio

!SLIDE bullets transition=uncover
# Bibliografía / Recursos
* A medida que se presenten los temas se indicarán las fuentes apropiadas
* Todo el material se encuentra bajo licencia **Creative Commons**:

<a rel="license"
  href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.es"><img
alt="Licencia Creative Commons" style="border-width:0"
src="http://i.creativecommons.org/l/by-nc-sa/3.0/88x31.png" /></a><br /><span
xmlns:dct="http://purl.org/dc/terms/" property="dct:title">TTPS - Opcion
Ruby</span> por <span xmlns:cc="http://creativecommons.org/ns#"
property="cc:attributionName">Christian A. Rodriguez</span> se encuentra bajo
una <a rel="license"
href="http://creativecommons.org/licenses/by-nc-sa/3.0/deed.es">Licencia
Creative Commons Atribución-NoComercial-CompartirIgual 3.0 Unported</a>.
