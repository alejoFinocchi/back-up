# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
LearnRails::Application.config.secret_key_base = 'ed48ce1a35fd4ef1a6e38ce8ad88feae6999982e17404e7303e8cb6812c9217dc18be6f7d88ee4e61239a645ad851519eaed34449f188b3d21110db0621aa1f5'
