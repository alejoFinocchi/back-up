class Product < ActiveRecord::Base; end

class ProductA < Product; end
class ProductB < Product; end
