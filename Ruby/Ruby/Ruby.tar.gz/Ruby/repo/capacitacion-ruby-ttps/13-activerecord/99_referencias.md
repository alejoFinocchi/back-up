!SLIDE smbullets transition=uncover
# Referencias

* [API](http://api.rubyonrails.org/classes/ActiveRecord/Base.html)
* [Active Record base](http://edgeguides.rubyonrails.org/active_record_basics.html)
* [Active Record Associations](http://guides.rubyonrails.org/association_basics.html)
* [Active Record Querying](http://edgeguides.rubyonrails.org/active_record_querying.html)
* [Active Record Validations](http://edgeguides.rubyonrails.org/active_record_validations.html)
* [Active Record
  Callbacks](http://edgeguides.rubyonrails.org/active_record_callbacks.html)
* [Active Record Migrations](http://edgeguides.rubyonrails.org/migrations.html)

## Desde Sinatra
* [Active Record y Sinatra](https://github.com/janko-m/sinatra-activerecord)
* [Active Record micro_migrations](https://github.com/svenfuchs/micro_migrations)

