!SLIDE center transition=uncover
# Gem

!SLIDE bullets small transition=uncover
# Introducción

* Una gema es un formato simple para publicar y compartir código Ruby.
* Cada gema tiene un nombre, versión y plataforma.

!SLIDE bullets small transition=uncover
# Comandos básicos

* Instalar una gema: `gem install rake`
* Buscar una gema: `gem search sinatra`
* Listar gemas instaladas: `gem list`
