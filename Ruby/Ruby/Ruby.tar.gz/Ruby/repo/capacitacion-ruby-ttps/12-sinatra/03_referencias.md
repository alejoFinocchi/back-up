!SLIDE bullets transition=uncover
# Referencias

* [Sitio web de Sinatra](http://www.sinatrarb.com/)

!SLIDE bullets transition=uncover
# Otros recursos

* [sinatra_ app_ template](https://github.com/ttps-ruby/sinatra_app_template)
