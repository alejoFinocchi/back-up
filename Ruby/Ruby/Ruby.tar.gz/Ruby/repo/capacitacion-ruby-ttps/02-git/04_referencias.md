!SLIDE bullets transition=uncover
# Referencias
* Lecturas
  * [Pro Git](http://git-scm.com/book)
  * [Git tutorial](https://www.kernel.org/pub/software/scm/git/docs/gittutorial.html)

* Juegos:
  * [tryGit](http://try.github.io/)
  * [GitHug](https://github.com/Gazler/githug)
  * [Learn git branching](http://pcottle.github.io/learnGitBranching)
