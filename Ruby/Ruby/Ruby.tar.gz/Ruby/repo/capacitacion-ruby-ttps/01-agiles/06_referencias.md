!SLIDE smbullets transition=uncover
# Referencias
* http://agilemanifesto.org/
* http://tastycupcakes.org/
* http://agilismoatwork.blogspot.com.ar/
* http://psw.tuneupprocess.com/
* http://softhouseeducation.com/en/produkt/scrum-five-minutes
* http://www.mountaingoatsoftware.com/
